package controller;

import model.Password;
import model.rules.IRule;
import model.RuleProvider;
import view.ConsoleView;

import java.util.List;

public class PasswordGame {
    private static PasswordGame INSTANCE;

    public static synchronized PasswordGame getInstance() {
        if (PasswordGame.INSTANCE == null) {
            PasswordGame.INSTANCE = new PasswordGame();
        }
        return PasswordGame.INSTANCE;
    }

    public void startNewGame() {
        ConsoleView view = new ConsoleView();
        view.printWelcomeMessage();

        Password password = new Password();
        List<IRule> rules = RuleProvider.getRules();

        for (int i = 0; i < rules.size(); i++) {
            IRule currentRule = rules.get(i);
            int stepNumber = i + 1;
            boolean allValid = false;

            view.printRuleDescription(stepNumber, currentRule);

            List<IRule> failedRules = List.of();

            while (!allValid) {
                if (!failedRules.isEmpty()) {
                    view.printFailedRules(failedRules);
                }

                String input = view.promptPasswordInput();
                password.setValue(input);

                failedRules = rules.subList(0, stepNumber).stream()
                        .filter(r -> !r.validate(password.getValue()))
                        .toList();

                if (failedRules.isEmpty()) {
                    allValid = true;
                }
            }
        }

        view.printSuccess();
    }


}
