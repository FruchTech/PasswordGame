package view;

import java.util.List;
import java.util.Scanner;

import model.rules.IRule;

public class ConsoleView {
    private final Scanner scanner = new Scanner(System.in);

    public void printWelcomeMessage() {
        System.out.println("=".repeat(75) +
                "HERZLICH WILLKOMMEN ZUM PASSWORDGAME!" +
                "=".repeat(75));
    }

    public String promptPasswordInput(int ruleNumber, IRule rule) {
        System.out.println("\n" + ruleNumber + ". " + rule.requirements() + ": ");
        return scanner.nextLine();
    }

    public void printFailedRules(List<IRule> failedRules) {
        System.out.println("Fehler! Folgende Anforderungen wurden nicht erfüllt:");
        for (IRule rule : failedRules) {
            System.out.println(" - " + rule.requirements());
        }
    }

    public void printRuleDescription(int ruleNumber, IRule rule) {
        System.out.println("\n" + ruleNumber + ". " + rule.requirements());
    }

    public String promptPasswordInput() {
        System.out.print("Bitte Passwort eingeben: ");
        return scanner.nextLine();
    }

    public void printSuccess() {
        System.out.println("\nGlückwunsch! Das Passwort erfüllt alle Anforderungen.");
    }
}
