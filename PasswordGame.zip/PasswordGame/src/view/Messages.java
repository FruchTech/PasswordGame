package view;

public class Messages {
}
