package model.rules;

public class UppercaseRule implements IRule {
    private final int minUppercase;

    public UppercaseRule() {
        this(3);
    }

    public UppercaseRule(int minUppercase) {
        this.minUppercase = minUppercase;
    }

    public String requirement() {
        return "Dein Passwort muss mindestens " + minUppercase + " Großbuchstaben enthalten";
    }

    public String shortRequirement() {
        return "Mind. " + minUppercase + " Großbuchstaben";
    }

    public boolean validate(String password) {
        long count = password.chars().filter(Character::isUpperCase).limit(minUppercase).count();
        return count >= 3;
    }

}
