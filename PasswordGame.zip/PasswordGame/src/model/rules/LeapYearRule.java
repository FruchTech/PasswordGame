package model.rules;

public class LeapYearRule implements IRule {

    public LeapYearRule() {
    }

    public String requirement() {
        return "Dein Passwort muss ein Schaltjahr enthalten";
    }

    public String shortRequirement() {
        return "Enthält Schaltjahr";
    }

    public boolean validate(String password) {
        return false;
    }

}
