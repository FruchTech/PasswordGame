package model.rules;

public interface IRule {

    String requirements();

    boolean validate(String password);
}
