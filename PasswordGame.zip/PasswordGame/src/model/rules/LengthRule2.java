package model.rules;

public class LengthRule2 implements IRule {
    private final int minLength;

    public LengthRule2() {
        this.minLength = 20;
    }

    public String requirements() {
        return "Das Passwort muss mindestens " + minLength + " Zeichen lang sein";
    }

    public boolean validate(String password) {
        return password.length() >= minLength;
    }
}
