package model.rules;

public class LengthRule implements IRule {
    private final int minLength;

    public LengthRule() {
        this.minLength = 8;
    }

    public String requirements() {
        return "Das Passwort muss mindestens " + minLength + " Zeichen lang sein";
    }

    public boolean validate(String password) {
        return password.length() >= minLength;
    }

}
