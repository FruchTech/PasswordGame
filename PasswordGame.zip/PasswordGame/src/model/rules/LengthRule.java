package model.rules;

public class LengthRule implements IRule {
    private final int minLength;

    public LengthRule() {
        this(8);
    }

    public LengthRule(int minLength) {
        this.minLength = minLength;
    }

    public String requirement() {
        return "Dein Passwort muss mindestens " + minLength + " Zeichen lang sein";
    }

    public String shortRequirement() {
        return "Mind. " + minLength + " Zeichen";
    }

    public boolean validate(String password) {
        return password.length() >= minLength;
    }

}
