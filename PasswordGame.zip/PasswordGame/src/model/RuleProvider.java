package model;

import model.rules.*;

import java.util.List;

public class RuleProvider {

    public static List<IRule> getRules() {
        return List.of(
                new LengthRule(),
                new NumberRule(),
                new UppercaseRule(),
                new SpecialCharacterRule(),
                new LeapYearRule()
        );
    }

}
