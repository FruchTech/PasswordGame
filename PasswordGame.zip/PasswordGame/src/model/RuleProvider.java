package model;

import model.rules.IRule;
import model.rules.LengthRule;
import model.rules.LengthRule2;

import java.util.List;

public class RuleProvider {
    public static List<IRule> getRules() {
        return List.of(new LengthRule(), new LengthRule2());
    }
}
