package model.rules;

public class AtosCEORule implements IRule {
    private final String[] ceoList;

    public AtosCEORule() {
        this(new String[]{"mustier", "saleh", "bernaert", "bihmane", "belmer"});
    }

    public AtosCEORule(String[] ceoList) {
        this.ceoList = ceoList;
    }

    public String requirement() {
        return "Dein Passwort muss den Nachnamen eines ehem. Atos CEOs enthalten";
    }

    public String shortRequirement() {
        return "Nachname Atos CEO";
    }

    public boolean validate(String password) {

        for (String s : ceoList) {
            if (password.toLowerCase().contains(s)) {
                return true;
            }
        }

        return false;
    }

}
