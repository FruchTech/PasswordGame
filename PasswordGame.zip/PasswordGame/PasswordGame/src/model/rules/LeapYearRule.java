package model.rules;

import java.util.regex.Matcher;

public class LeapYearRule implements IRule {
    private final int length;

    public LeapYearRule() {
        this(4);
    }

    public LeapYearRule(int length) {
        this.length = length;
    }

    public String requirement() {
        return "Dein Passwort muss ein " + length + "-stelliges Schaltjahr enthalten";
    }

    public String shortRequirement() {
        return "Enthält 5stelliges Schaltjahr";
    }

    public boolean validate(String password) {
        java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("\\d{5}").matcher(password);

        while (matcher.find()) {
            int year = Integer.parseInt(matcher.group());
            if (isLeapYear(year)) {
                return true;
            }
        }

        return false;
    }

    private boolean isLeapYear(int year) {
        return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
    }

}
