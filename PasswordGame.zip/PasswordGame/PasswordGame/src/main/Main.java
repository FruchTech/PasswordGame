package main;

import controller.PasswordGame;

public class Main {
    public static void main(String[] args) {
        PasswordGame.getInstance().startNewGame();
    }
}
